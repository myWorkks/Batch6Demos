package com.marolix.FunctionalInterface;

@FunctionalInterface
public interface FunctionalInterfaceDemo {

	void m1();

	default void m3() {
	}
//	void m2();

}
